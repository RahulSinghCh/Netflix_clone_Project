from django.http import HttpResponse
from django.shortcuts import render
from datetime import datetime
from djangoapp.models import Contact



# Create your views here.
def index(request):
    return render(request,'index.html')
def home(request):
    return render(request,'home.html')
def signup(request):
    return render(request, 'signup.html')
def login(request):
    return render(request,'login.html')
def about(request):
    return render(request,'about.html')
def contact(request):
    return render(request,'contact.html')
def save(request):
    if request.method =="POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        desc = request.POST.get('desc')
        en= Contact(name=name, email=email, desc=desc, date=datetime.today())
        en.save()
    return render(request,'contact.html')
def horror(request):
    return render(request,'horror.html')
def action(request):
    return render(request,'action.html')
def romantic(request):
    return render(request,'romantic.html')


    
