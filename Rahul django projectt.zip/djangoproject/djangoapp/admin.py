from django.contrib import admin
from djangoapp.models import Contact

# Register your models here.
admin.site.register(Contact)
